package pdsa_doctorappoinment;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Patient extends javax.swing.JFrame 
{
    private PatientQueue patientQueue;
    
    public Patient() 
    {
        initComponents();
        patientQueue = new PatientQueue(); //Initialize the PatientQueue
        
        // Add action listener to the Add button
        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleAddPatient();
            }
        });
        
        // Add action listener to the Delete button
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleDeletePatient();
            }
        });
    }
    
    // Method to handle adding a patient
    private void handleAddPatient() {
        try {
            int patientId = Integer.parseInt(PIdtxt.getText());
            String name = nametxt.getText();
            String address = addresstxt.getText();
            int age = Integer.parseInt(agetxt.getText());
            String contactNumber = contacttxt.getText();
            int doctorId = Integer.parseInt(DIdtxt.getText());

            patientQueue.enqueue(patientId, name, address, age, contactNumber, doctorId);

            JOptionPane.showMessageDialog(this, name + " inserted successfully.");
            
            // Clear the form fields after inserting
            clearForm();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid inputs.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Method to handle deleting a patient
    private void handleDeletePatient() {
        if (patientQueue.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Patient list is empty.");
        } else {
            patientQueue.dequeue();
            JOptionPane.showMessageDialog(this, "Patient removed successfully.");
        }
    }
    
    // Method to clear the form fields after adding a patient
    private void clearForm() {
        PIdtxt.setText("");
        nametxt.setText("");
        addresstxt.setText("");
        agetxt.setText("");
        contacttxt.setText("");
        DIdtxt.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        left = new javax.swing.JPanel();
        right = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Title = new javax.swing.JLabel();
        Name = new javax.swing.JLabel();
        Age = new javax.swing.JLabel();
        ContactNumber = new javax.swing.JLabel();
        contacttxt = new javax.swing.JTextField();
        nametxt = new javax.swing.JTextField();
        agetxt = new javax.swing.JTextField();
        addresstxt = new javax.swing.JTextField();
        Address = new javax.swing.JLabel();
        PatientId = new javax.swing.JLabel();
        PIdtxt = new javax.swing.JTextField();
        DoctorId = new javax.swing.JLabel();
        DIdtxt = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Patient");
        setPreferredSize(new java.awt.Dimension(800, 550));

        left.setBackground(new java.awt.Color(255, 255, 255));
        left.setPreferredSize(new java.awt.Dimension(800, 550));
        left.setLayout(null);

        right.setBackground(new java.awt.Color(0, 102, 102));
        right.setMinimumSize(new java.awt.Dimension(400, 500));
        right.setPreferredSize(new java.awt.Dimension(400, 550));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/logo.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("HEMAS Hospital Pvt(Ltd)");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("© HEMAS HEALTH 2024 All Rights Reserved");

        javax.swing.GroupLayout rightLayout = new javax.swing.GroupLayout(right);
        right.setLayout(rightLayout);
        rightLayout.setHorizontalGroup(
            rightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightLayout.createSequentialGroup()
                .addGroup(rightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rightLayout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(jLabel1))
                    .addGroup(rightLayout.createSequentialGroup()
                        .addGap(168, 168, 168)
                        .addComponent(jLabel3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rightLayout.createSequentialGroup()
                .addContainerGap(76, Short.MAX_VALUE)
                .addGroup(rightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rightLayout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(93, 93, 93))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rightLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(83, 83, 83))))
        );
        rightLayout.setVerticalGroup(
            rightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(jLabel3)
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 138, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(70, 70, 70))
        );

        left.add(right);
        right.setBounds(0, 0, 400, 550);
        right.getAccessibleContext().setAccessibleName("");
        right.getAccessibleContext().setAccessibleDescription("");

        Title.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        Title.setForeground(new java.awt.Color(0, 102, 102));
        Title.setText("PATIENT DETAILS");
        left.add(Title);
        Title.setBounds(470, 20, 310, 50);

        Name.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        Name.setText("Name :");
        left.add(Name);
        Name.setBounds(430, 80, 50, 21);

        Age.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        Age.setText("Age :");
        left.add(Age);
        Age.setBounds(430, 140, 50, 20);

        ContactNumber.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        ContactNumber.setText("Contact Number :");
        left.add(ContactNumber);
        ContactNumber.setBounds(430, 260, 150, 21);

        contacttxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contacttxtActionPerformed(evt);
            }
        });
        left.add(contacttxt);
        contacttxt.setBounds(430, 280, 320, 30);

        nametxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nametxtActionPerformed(evt);
            }
        });
        left.add(nametxt);
        nametxt.setBounds(430, 100, 320, 30);

        agetxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agetxtActionPerformed(evt);
            }
        });
        left.add(agetxt);
        agetxt.setBounds(430, 160, 320, 30);

        addresstxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addresstxtActionPerformed(evt);
            }
        });
        left.add(addresstxt);
        addresstxt.setBounds(430, 220, 320, 30);

        Address.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        Address.setText("Address :");
        left.add(Address);
        Address.setBounds(430, 200, 70, 21);

        PatientId.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        PatientId.setText("Patient Id (Your Password) :");
        left.add(PatientId);
        PatientId.setBounds(430, 320, 230, 21);

        PIdtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PIdtxtActionPerformed(evt);
            }
        });
        left.add(PIdtxt);
        PIdtxt.setBounds(430, 340, 320, 30);

        DoctorId.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        DoctorId.setText("Doctor Id :");
        left.add(DoctorId);
        DoctorId.setBounds(430, 380, 230, 21);

        DIdtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DIdtxtActionPerformed(evt);
            }
        });
        left.add(DIdtxt);
        DIdtxt.setBounds(430, 400, 320, 30);

        btnAdd.setBackground(new java.awt.Color(0, 102, 102));
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        left.add(btnAdd);
        btnAdd.setBounds(420, 450, 72, 23);

        btnDelete.setBackground(new java.awt.Color(0, 102, 102));
        btnDelete.setForeground(new java.awt.Color(255, 255, 255));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        left.add(btnDelete);
        btnDelete.setBounds(510, 450, 72, 23);

        btnNext.setBackground(new java.awt.Color(0, 102, 102));
        btnNext.setForeground(new java.awt.Color(255, 255, 255));
        btnNext.setText("Next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });
        left.add(btnNext);
        btnNext.setBounds(600, 450, 72, 23);

        btnBack.setBackground(new java.awt.Color(0, 102, 102));
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        left.add(btnBack);
        btnBack.setBounds(690, 450, 75, 23);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(left, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(left, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );

        left.getAccessibleContext().setAccessibleName("Patient");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void contacttxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contacttxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contacttxtActionPerformed

    private void nametxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nametxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nametxtActionPerformed

    private void agetxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agetxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_agetxtActionPerformed

    private void addresstxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addresstxtActionPerformed
    }//GEN-LAST:event_addresstxtActionPerformed

    private void PIdtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PIdtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PIdtxtActionPerformed

    private void DIdtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DIdtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DIdtxtActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        Doctor DoctorFrame = new Doctor();
        DoctorFrame.setVisible(true);
        DoctorFrame.pack();
        DoctorFrame.setLocationRelativeTo(null); 
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        Appointment AppointmentFrame = new Appointment(); 
        AppointmentFrame.setVisible(true);
        AppointmentFrame.pack();
        AppointmentFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnNextActionPerformed

   public static void main(String args[]) 
   {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new Patient().setVisible(true);
            }
        });
    }




    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Address;
    private javax.swing.JLabel Age;
    private javax.swing.JLabel ContactNumber;
    private javax.swing.JTextField DIdtxt;
    private javax.swing.JLabel DoctorId;
    private javax.swing.JLabel Name;
    private javax.swing.JTextField PIdtxt;
    private javax.swing.JLabel PatientId;
    private javax.swing.JLabel Title;
    private javax.swing.JTextField addresstxt;
    private javax.swing.JTextField agetxt;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnNext;
    private javax.swing.JTextField contacttxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel left;
    private javax.swing.JTextField nametxt;
    private javax.swing.JPanel right;
    // End of variables declaration//GEN-END:variables
}
