Create Table Doctor
(
	DoctorId varchar(50) Primary key,
    DoctorName varchar(100),
    Specialization varchar(100)
);
Create Table Patient
(
	PatientId varchar(50) Primary key,
    PatientName varchar(100),
    Age int,
    Address varchar(100),
    DoctorID varchar(50), 
    FOREIGN KEY (DoctorID) REFERENCES Doctor(DoctorId) 
);
Create Table Appointment
(
	AppointmentId int primary key AUTO_INCREMENT,
    Date date,
    Time time,
    DoctorID varchar(50), 
    FOREIGN KEY (DoctorID) REFERENCES Doctor(DoctorId),
    PatientId varchar(50), 
    FOREIGN KEY (PatientId) REFERENCES Patient(PatientId)
);
Create Table SignUp
(
	UserName varchar(50),
    Pwrd varchar(20) Primary key,
    Email varchar(50)
);
    