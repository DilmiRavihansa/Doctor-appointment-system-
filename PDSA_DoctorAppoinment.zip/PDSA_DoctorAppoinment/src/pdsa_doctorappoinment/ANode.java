
package pdsa_doctorappoinment;

import java.util.Date;

public class ANode
{
    public Date appDate;
    public int doctorId;
    public int patientId;
    public ANode nextNode;
    
    public ANode(Date appDate,int doctorId,int patientId)
    {
        this.doctorId=doctorId;
        this.patientId=patientId;
        this.appDate=new Date();
        this.nextNode=null;
    }
}
