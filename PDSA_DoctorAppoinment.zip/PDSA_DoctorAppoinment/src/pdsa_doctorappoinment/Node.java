
package pdsa_doctorappoinment;

public class Node 
{
    public int patientId;
    public String name;
    public String address;
    public int age;
    public String contactNumber;
    public int doctorId;
    public Node nextNode;
    
    public Node(int patientId,String name,String address,int age,String contactNumber,int doctorId)
    {
        this.patientId=patientId;
        this.name=name;
        this.address=address;
        this.age=age;
        this.contactNumber=contactNumber;
        this.doctorId=doctorId;
        this.nextNode=null;          
    }
}
