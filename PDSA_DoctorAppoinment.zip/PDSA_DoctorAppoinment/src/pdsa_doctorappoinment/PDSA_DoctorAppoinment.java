
package pdsa_doctorappoinment;

public class PDSA_DoctorAppoinment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Patient PatientFrame = new Patient(); 
        PatientFrame.setVisible(true);
        PatientFrame.pack();
        PatientFrame.setLocationRelativeTo(null); //center
        
        /*Login LoginFrame = new Login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);*/ 
        
        /*Doctor DoctorFrame = new Doctor(); 
        DoctorFrame.setVisible(true);
        DoctorFrame.pack();
        DoctorFrame.setLocationRelativeTo(null);*/
        
        /*Appointment AppointmentFrame = new Appointment(); 
        AppointmentFrame.setVisible(true);
        AppointmentFrame.pack();
        AppointmentFrame.setLocationRelativeTo(null);*/
    }
    
}
