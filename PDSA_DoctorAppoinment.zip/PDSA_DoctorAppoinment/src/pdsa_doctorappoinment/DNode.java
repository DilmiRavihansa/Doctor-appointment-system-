
package pdsa_doctorappoinment;

public class DNode 
{
    public String name;
    public String specialization;
    public int doctorId;
    public DNode nextNode;
    
    public DNode(String name,String specialization,int doctorId)
    {
        this.name=name;
        this.specialization=specialization;
        this.doctorId=doctorId;
        this.nextNode=null;
    }
}
