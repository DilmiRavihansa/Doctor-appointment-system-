
package pdsa_doctorappoinment;

public class Home extends javax.swing.JFrame {
   
    public Home() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Home");
        getContentPane().setLayout(null);

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\sadun kumara\\Pictures\\Doctor Appoiment\\Icone\\6040299_asian_coronavirus_doctor_male_icon.png")); // NOI18N
        getContentPane().add(jLabel3);
        jLabel3.setBounds(180, 160, 120, 108);

        jButton1.setFont(new java.awt.Font("Bookman Old Style", 1, 24)); // NOI18N
        jButton1.setText("DOCTOR");
        getContentPane().add(jButton1);
        jButton1.setBounds(170, 280, 141, 36);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\sadun kumara\\Pictures\\Doctor Appoiment\\Icone\\5958347_disease_epidemic_infection_patient_sufferer_icon.png")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(450, 150, 125, 110);

        jButton2.setFont(new java.awt.Font("Bookman Old Style", 1, 24)); // NOI18N
        jButton2.setText("PATIENT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(440, 280, 142, 36);

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\sadun kumara\\Pictures\\Doctor Appoiment\\Icone\\3405112_appointment_calendar_date_day_event_icon.png")); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(670, 150, 154, 116);

        jButton4.setFont(new java.awt.Font("Bookman Old Style", 1, 24)); // NOI18N
        jButton4.setText("Appoiment");
        getContentPane().add(jButton4);
        jButton4.setBounds(660, 280, 180, 36);

        jLabel5.setFont(new java.awt.Font("Monotype Corsiva", 1, 48)); // NOI18N
        jLabel5.setText("    Doctor Appointment Booking System...");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(0, 10, 800, 60);

        jButton3.setForeground(new java.awt.Color(153, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\sadun kumara\\Pictures\\Doctor Appoiment\\Icone\\8679806_login_box_icon (1).png")); // NOI18N
        getContentPane().add(jButton3);
        jButton3.setBounds(940, 20, 40, 50);

        jLabel6.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 0, 0));
        jLabel6.setText("Login");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(877, 30, 60, 30);

        jLabel7.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        jLabel7.setText("Ease scheduling pains with a doctor appointment booking app.");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(140, 350, 630, 30);

        jLabel8.setFont(new java.awt.Font("Rockwell", 1, 12)); // NOI18N
        jLabel8.setText("Empower your patients to book or reschedule");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(140, 390, 370, 20);

        jLabel9.setFont(new java.awt.Font("Rockwell", 1, 12)); // NOI18N
        jLabel9.setText("appointments online 24/7. Reduce average booking time");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(140, 395, 300, 40);

        jLabel10.setFont(new java.awt.Font("Rockwell", 1, 12)); // NOI18N
        jLabel10.setText("from 8+ minutes by phone* to just a few clicks.");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(140, 430, 280, 15);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\sadun kumara\\Pictures\\Doctor Appoiment\\1000_F_815586595_PJGF1V6kQBaUcNHgsx1dbnG7dAwIE2xY.jpg")); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, -50, 1000, 560);

        setSize(new java.awt.Dimension(1006, 513));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
