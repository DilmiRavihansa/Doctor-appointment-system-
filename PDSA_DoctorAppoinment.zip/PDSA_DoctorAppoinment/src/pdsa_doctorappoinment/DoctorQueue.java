package pdsa_doctorappoinment;

public class DoctorQueue {
    public DNode front, rear;
    
    public DoctorQueue() {
        front = null;
        rear = null;
    }
    
    public boolean isEmpty() {
        return front == null && rear == null;
    }
    
    public void enqueue(String name, String specialization, int doctorId) {
        DNode n1 = new DNode(name, specialization, doctorId);
        
        if (isEmpty()) {
            front = n1;
        } else {
            rear.nextNode = n1;  // Link the old rear to the new node
        }
        
        rear = n1;  // Update rear to the new node
        System.out.println(name + " inserted successfully");
    }
    
    public void dequeue() {
        if (isEmpty()) {
            System.out.println("Doctor list is empty");
            return;
        }
        
        System.out.println(front.name + " with Doctor ID " + front.doctorId + " is removed");
        front = front.nextNode;  // Move front to the next node
        
        if (front == null) {  // If the queue becomes empty, set rear to null
            rear = null;
        }
    }
    
    public void print() 
    {
        if (isEmpty()) 
        {
            System.out.println("Doctor list is empty");
            return;
        }
        
        DNode temp = front;
        while (temp != null) 
        {
            System.out.print("Name: " + temp.name + ", Specialization: " + temp.specialization + ", Doctor ID: " + temp.doctorId);
            if (temp.nextNode != null) 
            {
                System.out.print(" -> ");
            }
            temp = temp.nextNode;
        }
        System.out.println();  // Move to the next line after printing the queue
    }
}
