package pdsa_doctorappoinment;

public class PatientQueue
{
    public Node front,rear;
    
    public PatientQueue()
    {
        front=null;
        rear=null;
    }
    
    public boolean isEmpty()
    {
        return front==null && rear==null;
    }
    
    public void enqueue(int patientId,String name,String address,int age,String contactNumber,int doctorId)
    {
        Node n1=new Node(patientId,name,address,age,contactNumber,doctorId);
        if(isEmpty())
        {
            front=n1;
        }
        else
        {
            rear.nextNode=n1;
        }
        rear=n1;
        System.out.println(name+"Inserted Successfully");
    }
    
    public void dequeue()
    {
        if(isEmpty())
        {
            System.out.println("Patient list is empty");
            return;
        }
        System.out.println(front.name+"with Patient ID"+front.patientId+"is Removed");
        front=front.nextNode;
        if(front==null)
        {
            rear=null;
        }
    } 
}