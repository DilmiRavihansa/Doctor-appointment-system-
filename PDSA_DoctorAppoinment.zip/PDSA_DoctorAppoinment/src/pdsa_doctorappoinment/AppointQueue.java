
package pdsa_doctorappoinment;

import java.util.Date;

public class AppointQueue 
{
    public ANode front,rear;
    
    public AppointQueue()
    {
        front=null;
        rear=null;
    }
    
    public boolean isEmpty()
    {
        return front==null && rear==null;
    }
    
    public void enqueue(Date appDate,int doctorId,int patientId)
    {
        ANode n1=new ANode(appDate,doctorId,patientId);
        if(isEmpty())
        {
            front=n1;
        }
        else
        {
            rear.nextNode=n1;
        }
        rear=n1;
        System.out.println(patientId+ "Appointment Successfully");
    }
    
    public void dequeue()
    {
        if(isEmpty())
        {
            System.out.println("Appointment list is Empty");
            return;
        }
        System.out.println(front.patientId + " with Doctor ID " + front.doctorId + " is removed");
        front = front.nextNode;  // Move front to the next node
        
        if (front == null) {  // If the queue becomes empty, set rear to null
            rear = null;
        }
    }   
}
